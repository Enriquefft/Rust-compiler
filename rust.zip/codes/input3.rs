fn main() {
    let mut x: i32;

    x = 1;

    for i in 0..10 { // i is a i32
        x += i;
    }

    println!("{}", x);
}
