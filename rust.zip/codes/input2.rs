fn main() {
    let mut x: i32;
    let mut y: i32;

    x = 5;
    y = 10;

    if x > y {
        println!("{}", x);
    } else {
        println!("{}", y);
    }

}
