// dummy_lib.rs
// Exists only so Cargo has a target; not actually used.
fn _dummy() {}
