// Tests unsafe block as expression
fn main() {
    let x: i32 = unsafe { 42 };
    println!("{}", x);
}
