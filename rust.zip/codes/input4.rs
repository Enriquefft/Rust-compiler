fn suma(a: i32, b: i32) -> i32 {
    a + b
}

fn main() {
    let mut x: i32;
    let mut y: i32;
    x = 1;
    y = 20;
    println!("{}", suma(x, y));
}
