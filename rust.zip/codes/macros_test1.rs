// Tests macro call syntax treated as function call
fn main() {
    println!("hello from println!");
}
