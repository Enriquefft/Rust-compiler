// Tests macro calls with multiple arguments
fn log_values(a: i32, b: i32) {
    println!("a = {}, b = {}", a, b);
}

fn main() {
    log_values(3, 4);
}
