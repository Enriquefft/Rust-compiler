fn main() {
    let mut x: i32;
    let mut y: i32;
    let mut z: i64;

    x = 1;
    y = 10;
    z = 1000000;
    x = 20;

    println!("{}", x);
    println!("{}", y);
    println!("{}", z);
}
